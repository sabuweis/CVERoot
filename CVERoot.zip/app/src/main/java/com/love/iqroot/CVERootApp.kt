package com.love.iqroot
import android.app.Application
class CVERootApp : Application() {
    override fun onCreate() { super.onCreate(); instance = this }
    companion object { lateinit var instance: CVERootApp; private set }
}
