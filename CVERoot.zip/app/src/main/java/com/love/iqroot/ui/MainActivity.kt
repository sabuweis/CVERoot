package com.love.iqroot.ui
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import com.love.iqroot.ui.component.bottombar.BottomBar
import com.love.iqroot.ui.component.bottombar.MainPagerState
import com.love.iqroot.ui.component.bottombar.rememberMainPagerState
import com.love.iqroot.ui.navigation3.LocalNavigator
import com.love.iqroot.ui.navigation3.Route
import com.love.iqroot.ui.navigation3.rememberNavigator
import com.love.iqroot.ui.screen.colorpalette.ColorPaletteScreen
import com.love.iqroot.ui.screen.home.HomePager
import com.love.iqroot.ui.screen.placeholder.PlaceholderScreen
import com.love.iqroot.ui.screen.settings.SettingPager
import com.love.iqroot.ui.theme.KernelSUTheme
import com.love.iqroot.ui.theme.LocalColorMode
import com.love.iqroot.ui.theme.LocalEnableBlur
import com.love.iqroot.ui.theme.LocalEnableFloatingBottomBar
import com.love.iqroot.ui.theme.LocalEnableFloatingBottomBarBlur
import com.love.iqroot.ui.util.rememberBlurBackdrop
import com.love.iqroot.ui.viewmodel.MainActivityViewModel
import com.love.iqroot.ui.viewmodel.MainPagerConfig
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.blur.rememberLayerBackdrop
import top.yukonga.miuix.kmp.theme.MiuixTheme
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel = viewModel<MainActivityViewModel>()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val selectedMainPage by viewModel.selectedMainPage.collectAsStateWithLifecycle()
            val appSettings = uiState.appSettings
            val darkMode = appSettings.colorMode.isDark || (appSettings.colorMode.isSystem && isSystemInDarkTheme())
            DisposableEffect(darkMode) {
                enableEdgeToEdge(SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { darkMode }, SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { darkMode })
                window.isNavigationBarContrastEnforced = false; onDispose { }
            }
            val navigator = rememberNavigator(Route.Main)
            val systemDensity = LocalDensity.current
            val density = remember(systemDensity, uiState.pageScale) { Density(systemDensity.density * uiState.pageScale, systemDensity.fontScale) }
            CompositionLocalProvider(
                LocalNavigator provides navigator, LocalDensity provides density,
                LocalColorMode provides appSettings.colorMode.value,
                LocalEnableBlur provides uiState.enableBlur,
                LocalEnableFloatingBottomBar provides uiState.enableFloatingBottomBar,
                LocalEnableFloatingBottomBarBlur provides uiState.enableFloatingBottomBarBlur,
            ) {
                KernelSUTheme(appSettings = appSettings) {
                    val mainEntry = @Composable { MainScreen(initialPage = selectedMainPage, onPageChanged = viewModel::setSelectedMainPage) }
                    NavDisplay(backStack = navigator.backStack, entryDecorators = listOf(rememberSaveableStateHolderNavEntryDecorator()), onBack = { navigator.pop() }, entryProvider = entryProvider {
                        entry<Route.Main> { mainEntry() }; entry<Route.Home> { mainEntry() }; entry<Route.Settings> { mainEntry() }
                        entry<Route.ColorPalette> { ColorPaletteScreen(navigator) }
                        entry<Route.About> { PlaceholderScreen(navigator, "关于") }
                        entry<Route.KSuRoot> { PlaceholderScreen(navigator, "KSuRoot") }
                        entry<Route.GhostLock> { PlaceholderScreen(navigator, "GhostLock") }
                    })
                }
            }
        }
    }
}
val LocalMainPagerState = staticCompositionLocalOf<MainPagerState> { error("LocalMainPagerState not provided") }
@Composable
fun MainScreen(initialPage: Int = 0, onPageChanged: (Int) -> Unit = {}) {
    val enableBlur = LocalEnableBlur.current
    val enableFloatingBottomBar = LocalEnableFloatingBottomBar.current
    val enableGlass = LocalEnableFloatingBottomBarBlur.current
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { MainPagerConfig.PAGE_COUNT })
    val mainPagerState = rememberMainPagerState(pagerState)
    val surfaceColor = MiuixTheme.colorScheme.surface
    val blurBackdrop = rememberBlurBackdrop(enableBlur)
    val backdrop = rememberLayerBackdrop { drawRect(surfaceColor); drawContent() }
    LaunchedEffect(pagerState.settledPage) { onPageChanged(pagerState.settledPage) }
    LaunchedEffect(pagerState.currentPage) { mainPagerState.syncPage() }
    CompositionLocalProvider(LocalMainPagerState provides mainPagerState) {
        val pagerContent = @Composable { bottomInnerPadding: Dp ->
            Box(modifier = if (blurBackdrop != null) Modifier.layerBackdrop(blurBackdrop) else Modifier) {
                HorizontalPager(modifier = Modifier.then(if (enableFloatingBottomBar && enableGlass) Modifier.layerBackdrop(backdrop) else Modifier), state = pagerState, beyondViewportPageCount = 1, overscrollEffect = null, userScrollEnabled = false) { page ->
                    when (page) { 0 -> HomePager(LocalNavigator.current, bottomInnerPadding, true); 1 -> SettingPager(LocalNavigator.current, bottomInnerPadding) }
                }
            }
        }
        val bottomBar = @Composable { Box(modifier = Modifier.fillMaxWidth()) { BottomBar(blurBackdrop, backdrop, Modifier.align(Alignment.BottomCenter)) } }
        Scaffold(bottomBar = bottomBar) { innerPadding -> pagerContent(innerPadding.calculateBottomPadding()) }
    }
}
