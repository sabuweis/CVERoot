package com.love.iqroot.ui.screen.settings

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.unit.Dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.love.iqroot.ui.navigation3.Navigator
import com.love.iqroot.ui.navigation3.Route
import com.love.iqroot.ui.viewmodel.SettingsViewModel

@Composable
fun SettingPager(navigator: Navigator, bottomInnerPadding: Dp) {
    val viewModel = viewModel<SettingsViewModel>()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    LifecycleResumeEffect(Unit) { viewModel.refresh(); onPauseOrDispose { } }

    val actions = SettingsScreenActions(
        onOpenTheme = { navigator.push(Route.ColorPalette) },
        onSetDebugLog = viewModel::setDebugLog,
        onSendLog = { viewModel.exportLog() },
        onOpenAbout = { navigator.push(Route.About) },
        onSetUiModeIndex = { idx ->
            viewModel.setUiMode(if (idx == 0) "miuix" else "material")
        },
        onSetColorMode = viewModel::setColorMode,
        onSetThemeMode = viewModel::setColorMode,
        onSetMiuixMonet = viewModel::setMiuixMonet,
        onSetKeyColor = viewModel::setKeyColor,
        onSetColorStyle = viewModel::setColorStyle,
        onSetColorSpec = viewModel::setColorSpec,
        onSetEnableBlur = viewModel::setEnableBlur,
        onSetEnableFloatingBottomBar = viewModel::setEnableFloatingBottomBar,
        onSetEnableFloatingBottomBarBlur = viewModel::setEnableFloatingBottomBarBlur,
        onSetEnableNavigationBadge = viewModel::setEnableNavigationBadge,
        onSetEnablePredictiveBack = viewModel::setEnablePredictiveBack,
        onSetPageScale = viewModel::setPageScale,
    )

    SettingPagerMiuix(uiState, actions, bottomInnerPadding)
}
