package com.love.iqroot.data.repository

import android.content.Context
import androidx.core.content.edit
import com.love.iqroot.CVERootApp

class SettingsRepositoryImpl : SettingsRepository {
    private val prefs by lazy {
        CVERootApp.instance.getSharedPreferences("settings", Context.MODE_PRIVATE)
    }
    override var themeMode: Int
        get() = prefs.getInt("color_mode", 0)
        set(v) = prefs.edit { putInt("color_mode", v) }
    override var miuixMonet: Boolean
        get() = prefs.getBoolean("miuix_monet", false)
        set(v) = prefs.edit { putBoolean("miuix_monet", v) }
    override var keyColor: Int
        get() = prefs.getInt("key_color", 0)
        set(v) = prefs.edit { putInt("key_color", v) }
    override var colorStyle: String
        get() = prefs.getString("color_style", "TonalSpot") ?: "TonalSpot"
        set(v) = prefs.edit { putString("color_style", v) }
    override var colorSpec: String
        get() = prefs.getString("color_spec", "SPEC_2025") ?: "SPEC_2025"
        set(v) = prefs.edit { putString("color_spec", v) }
    override var enablePredictiveBack: Boolean
        get() = prefs.getBoolean("enable_predictive_back", true)
        set(v) = prefs.edit { putBoolean("enable_predictive_back", v) }
    override var enableBlur: Boolean
        get() = prefs.getBoolean("enable_blur", true)
        set(v) = prefs.edit { putBoolean("enable_blur", v) }
    override var enableFloatingBottomBar: Boolean
        get() = prefs.getBoolean("enable_floating_bottom_bar", true)
        set(v) = prefs.edit { putBoolean("enable_floating_bottom_bar", v) }
    override var enableFloatingBottomBarBlur: Boolean
        get() = prefs.getBoolean("enable_floating_bottom_bar_blur", true)
        set(v) = prefs.edit { putBoolean("enable_floating_bottom_bar_blur", v) }
    override var enableNavigationBadge: Boolean
        get() = prefs.getBoolean("enable_navigation_badge", true)
        set(v) = prefs.edit { putBoolean("enable_navigation_badge", v) }
    override var pageScale: Float
        get() = prefs.getFloat("page_scale", 1.0f)
        set(v) = prefs.edit { putFloat("page_scale", v) }
    override var debugLog: Boolean
        get() = prefs.getBoolean("debug_log", false)
        set(v) = prefs.edit { putBoolean("debug_log", v) }
    override var uiMode: String
        get() = prefs.getString("ui_mode", "miuix") ?: "miuix"
        set(v) = prefs.edit { putString("ui_mode", v) }
    override var wallpaperMode: Int
        get() = prefs.getInt("wallpaper_mode", 0)
        set(v) = prefs.edit { putInt("wallpaper_mode", v) }
    override var wallpaperIndependent: Boolean
        get() = prefs.getBoolean("wallpaper_independent", false)
        set(v) = prefs.edit { putBoolean("wallpaper_independent", v) }
    override var wallpaperLightPath: String
        get() = prefs.getString("wallpaper_light_path", "") ?: ""
        set(v) = prefs.edit { putString("wallpaper_light_path", v) }
    override var wallpaperDarkPath: String
        get() = prefs.getString("wallpaper_dark_path", "") ?: ""
        set(v) = prefs.edit { putString("wallpaper_dark_path", v) }
}
