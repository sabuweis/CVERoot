package com.love.iqroot.ui.screen.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object WallpaperUtils {

    private const val MAX_DIM = 4096

    fun singleFile(context: Context): File = File(context.filesDir, "wallpaper.png")
    fun lightFile(context: Context): File = File(context.filesDir, "wallpaper_light.png")
    fun darkFile(context: Context): File = File(context.filesDir, "wallpaper_dark.png")

    suspend fun convertUriToPng(context: Context, uri: Uri, dest: File): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val input = context.contentResolver.openInputStream(uri) ?: return@withContext false
                val bytes = input.readBytes()
                input.close()
                val bitmap = decodeSampled(bytes) ?: return@withContext false
                writeBitmap(bitmap, dest)
            } catch (_: Exception) { false }
        }

    suspend fun convertPathToPng(srcPath: String, dest: File): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val src = File(srcPath)
                if (!src.exists() || !src.isFile) return@withContext false
                val bytes = src.readBytes()
                val bitmap = decodeSampled(bytes) ?: return@withContext false
                writeBitmap(bitmap, dest)
            } catch (_: Exception) { false }
        }

    private fun decodeSampled(bytes: ByteArray): Bitmap? {
        if (bytes.isEmpty()) return null
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
        val sample = calcInSampleSize(opts.outWidth, opts.outHeight, MAX_DIM)
        val opts2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts2) ?: return null
        return scaleDown(bmp, MAX_DIM)
    }

    private fun calcInSampleSize(w: Int, h: Int, max: Int): Int {
        var sample = 1
        var cw = w
        var ch = h
        while (cw / 2 >= max && ch / 2 >= max) { cw /= 2; ch /= 2; sample *= 2 }
        return sample
    }

    private fun scaleDown(bitmap: Bitmap, maxDim: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val longest = maxOf(w, h)
        if (longest <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / longest
        val nw = (w * ratio).toInt().coerceAtLeast(1)
        val nh = (h * ratio).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(bitmap, nw, nh, true)
        if (scaled !== bitmap) bitmap.recycle()
        return scaled
    }

    private fun writeBitmap(bitmap: Bitmap, dest: File): Boolean {
        return try {
            dest.parentFile?.mkdirs()
            dest.outputStream().use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
            bitmap.recycle()
            true
        } catch (_: Exception) { false }
    }
}
