package com.love.iqroot.ui.viewmodel

import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.love.iqroot.CVERootApp
import com.love.iqroot.data.repository.SettingsRepository
import com.love.iqroot.data.repository.SettingsRepositoryImpl
import com.love.iqroot.ui.screen.settings.SettingsUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class SettingsViewModel(
    private val repo: SettingsRepository = SettingsRepositoryImpl()
) : ViewModel() {
    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init { refresh() }

    fun refresh() {
        _uiState.update {
            it.copy(
                uiMode = repo.uiMode,
                colorMode = repo.themeMode,
                miuixMonet = repo.miuixMonet,
                keyColor = repo.keyColor,
                colorStyle = repo.colorStyle,
                colorSpec = repo.colorSpec,
                themeMode = repo.themeMode,
                enablePredictiveBack = repo.enablePredictiveBack,
                enableBlur = repo.enableBlur,
                enableFloatingBottomBar = repo.enableFloatingBottomBar,
                enableFloatingBottomBarBlur = repo.enableFloatingBottomBarBlur,
                enableNavigationBadge = repo.enableNavigationBadge,
                pageScale = repo.pageScale,
                debugLog = repo.debugLog,
                wallpaperMode = repo.wallpaperMode,
                wallpaperIndependent = repo.wallpaperIndependent,
                wallpaperLightPath = repo.wallpaperLightPath,
                wallpaperDarkPath = repo.wallpaperDarkPath,
            )
        }
    }

    fun setUiMode(mode: String) { repo.uiMode = mode; _uiState.update { it.copy(uiMode = mode) } }
    fun setColorMode(m: Int) { repo.themeMode = m; _uiState.update { it.copy(colorMode = m, themeMode = m) } }
    fun setMiuixMonet(v: Boolean) { repo.miuixMonet = v; _uiState.update { it.copy(miuixMonet = v) } }
    fun setKeyColor(c: Int) { repo.keyColor = c; _uiState.update { it.copy(keyColor = c) } }
    fun setColorStyle(s: String) { repo.colorStyle = s; _uiState.update { it.copy(colorStyle = s) } }
    fun setColorSpec(s: String) { repo.colorSpec = s; _uiState.update { it.copy(colorSpec = s) } }
    fun setEnablePredictiveBack(v: Boolean) { repo.enablePredictiveBack = v; _uiState.update { it.copy(enablePredictiveBack = v) } }
    fun setEnableBlur(v: Boolean) { repo.enableBlur = v; _uiState.update { it.copy(enableBlur = v) } }
    fun setEnableFloatingBottomBar(v: Boolean) { repo.enableFloatingBottomBar = v; _uiState.update { it.copy(enableFloatingBottomBar = v) } }
    fun setEnableFloatingBottomBarBlur(v: Boolean) { repo.enableFloatingBottomBarBlur = v; _uiState.update { it.copy(enableFloatingBottomBarBlur = v) } }
    fun setEnableNavigationBadge(v: Boolean) { repo.enableNavigationBadge = v; _uiState.update { it.copy(enableNavigationBadge = v) } }
    fun setPageScale(s: Float) { repo.pageScale = s; _uiState.update { it.copy(pageScale = s) } }
    fun setDebugLog(v: Boolean) { repo.debugLog = v; _uiState.update { it.copy(debugLog = v) } }
    fun setWallpaperMode(v: Int) { repo.wallpaperMode = v; _uiState.update { it.copy(wallpaperMode = v) } }
    fun setWallpaperIndependent(v: Boolean) { repo.wallpaperIndependent = v; _uiState.update { it.copy(wallpaperIndependent = v) } }
    fun setWallpaperLightPath(v: String) { repo.wallpaperLightPath = v; _uiState.update { it.copy(wallpaperLightPath = v) } }
    fun setWallpaperDarkPath(v: String) { repo.wallpaperDarkPath = v; _uiState.update { it.copy(wallpaperDarkPath = v) } }

    fun exportLog() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val dir = File("/sdcard/Download")
                if (!dir.exists()) dir.mkdirs()
                File(dir, "cveroot-log-${System.currentTimeMillis()}.txt").writeText("CVERoot log\n")
                withContext(Dispatchers.Main) {
                    Toast.makeText(CVERootApp.instance, "日志已导出到 Download", Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) { }
        }
    }
}
