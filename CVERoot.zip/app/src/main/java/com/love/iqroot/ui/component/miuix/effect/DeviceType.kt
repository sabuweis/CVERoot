// Mirrored from compose-miuix-ui example.

package com.love.iqroot.ui.component.miuix.effect

enum class DeviceType {
    PHONE,
    PAD,
}
