package com.love.iqroot.ui.screen.home
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import com.love.iqroot.ui.navigation3.Navigator
import com.love.iqroot.ui.navigation3.Route
@Composable
fun HomePager(navigator: Navigator, bottomInnerPadding: Dp, isCurrentPage: Boolean = true) {
    HomePagerMiuix(onKSuRootClick = { navigator.push(Route.KSuRoot) }, onGhostLockClick = { navigator.push(Route.GhostLock) }, bottomInnerPadding = bottomInnerPadding)
}
