package com.love.iqroot.ui.screen.wallpaper

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.love.iqroot.ui.navigation3.Navigator
import com.love.iqroot.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun WallpaperScreen(navigator: Navigator) {
    val context = LocalContext.current
    val vm = viewModel<SettingsViewModel>()
    val s by vm.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var pendingIsDark by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val dest = resolveDest(context, s.wallpaperIndependent, pendingIsDark)
                val ok = WallpaperUtils.convertUriToPng(context, uri, dest)
                if (ok) {
                    if (s.wallpaperIndependent && pendingIsDark) vm.setWallpaperDarkPath(dest.absolutePath)
                    else vm.setWallpaperLightPath(dest.absolutePath)
                }
            }
        }
    }

    val state = WallpaperUiState(
        mode = s.wallpaperMode,
        independent = s.wallpaperIndependent,
        lightPath = s.wallpaperLightPath,
        darkPath = s.wallpaperDarkPath,
    )
    val actions = WallpaperScreenActions(
        onBack = { navigator.pop() },
        onSetMode = vm::setWallpaperMode,
        onSetIndependent = vm::setWallpaperIndependent,
        onSetLightPath = vm::setWallpaperLightPath,
        onSetDarkPath = vm::setWallpaperDarkPath,
    )

    WallpaperScreenMiuix(
        state = state,
        actions = actions,
        onPickFromGallery = { isDark ->
            pendingIsDark = isDark
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        },
        onPickFromPath = { isDark, path ->
            scope.launch {
                val dest = resolveDest(context, state.independent, isDark)
                val ok = WallpaperUtils.convertPathToPng(path.trim(), dest)
                if (ok) {
                    if (state.independent && isDark) vm.setWallpaperDarkPath(dest.absolutePath)
                    else vm.setWallpaperLightPath(dest.absolutePath)
                }
            }
        },
    )
}

private fun resolveDest(context: Context, independent: Boolean, isDark: Boolean): File {
    return if (!independent) WallpaperUtils.singleFile(context)
    else if (isDark) WallpaperUtils.darkFile(context)
    else WallpaperUtils.lightFile(context)
}
