package com.love.iqroot.ui.screen.wallpaper

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.love.iqroot.R
import com.love.iqroot.ui.theme.LocalEnableBlur
import com.love.iqroot.ui.util.BlurredBar
import com.love.iqroot.ui.util.rememberBlurBackdrop
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.TabRow
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
import java.io.File

@Composable
fun WallpaperScreenMiuix(
    state: WallpaperUiState,
    actions: WallpaperScreenActions,
    onPickFromGallery: (isDark: Boolean) -> Unit,
    onPickFromPath: (isDark: Boolean, path: String) -> Unit,
) {
    val scrollBehavior = MiuixScrollBehavior()
    val enableBlur = LocalEnableBlur.current
    val backdrop = rememberBlurBackdrop(enableBlur)
    val barColor = if (backdrop != null) Color.Transparent else colorScheme.surface

    var showDialog by remember { mutableStateOf(false) }
    var dialogIsDark by remember { mutableStateOf(false) }
    var pathText by remember(showDialog) { mutableStateOf("") }

    Scaffold(
        topBar = {
            BlurredBar(backdrop) {
                TopAppBar(
                    color = barColor,
                    title = stringResource(R.string.settings_wallpaper),
                    navigationIcon = {
                        IconButton(onClick = actions.onBack) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = null,
                                tint = colorScheme.onBackground,
                            )
                        }
                    },
                    scrollBehavior = scrollBehavior,
                )
            }
        },
        popupHost = { },
        contentWindowInsets = WindowInsets.systemBars
            .add(WindowInsets.displayCutout)
            .only(WindowInsetsSides.Horizontal),
    ) { innerPadding ->
        Box(modifier = if (backdrop != null) Modifier.layerBackdrop(backdrop) else Modifier) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxHeight()
                    .scrollEndHaptic()
                    .overScrollVertical()
                    .nestedScroll(scrollBehavior.nestedScrollConnection)
                    .padding(horizontal = 12.dp),
                contentPadding = innerPadding,
                overscrollEffect = null,
            ) {
                item {
                    Spacer(Modifier.height(16.dp))

                    TabRow(
                        tabs = listOf(
                            stringResource(R.string.wallpaper_tab_default),
                            stringResource(R.string.wallpaper_tab_custom),
                        ),
                        selectedTabIndex = state.mode.coerceIn(0, 1),
                        onTabSelected = actions.onSetMode,
                    )

                    if (state.mode == 1) {
                        Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) {
                            SwitchPreference(
                                title = stringResource(R.string.wallpaper_independent),
                                summary = stringResource(R.string.wallpaper_independent_summary),
                                checked = state.independent,
                                onCheckedChange = actions.onSetIndependent,
                            )
                        }

                        Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) {
                            if (state.independent) {
                                WallpaperSlotRow(
                                    label = stringResource(R.string.wallpaper_light),
                                    path = state.lightPath,
                                    onAdd = { dialogIsDark = false; pathText = ""; showDialog = true },
                                )
                                WallpaperSlotRow(
                                    label = stringResource(R.string.wallpaper_dark),
                                    path = state.darkPath,
                                    onAdd = { dialogIsDark = true; pathText = ""; showDialog = true },
                                )
                            } else {
                                WallpaperSlotRow(
                                    label = stringResource(R.string.wallpaper_custom),
                                    path = state.lightPath,
                                    onAdd = { dialogIsDark = false; pathText = ""; showDialog = true },
                                )
                            }
                        }
                    } else {
                        Text(
                            text = stringResource(R.string.wallpaper_default_hint),
                            modifier = Modifier.padding(24.dp),
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                    }

                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    OverlayDialog(
        show = showDialog,
        title = stringResource(R.string.wallpaper_add),
        summary = "",
        onDismissRequest = { showDialog = false },
        content = {
            TextField(
                value = pathText,
                onValueChange = { pathText = it },
                modifier = Modifier.padding(bottom = 16.dp),
            )
            Column {
                TextButton(
                    text = stringResource(R.string.wallpaper_pick_gallery),
                    onClick = {
                        onPickFromGallery(dialogIsDark)
                        showDialog = false
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(
                        text = stringResource(android.R.string.cancel),
                        onClick = { showDialog = false },
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(20.dp))
                    TextButton(
                        text = stringResource(android.R.string.ok),
                        onClick = {
                            if (pathText.isNotBlank()) onPickFromPath(dialogIsDark, pathText)
                            showDialog = false
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.textButtonColorsPrimary(),
                    )
                }
            }
        }
    )
}

@Composable
private fun WallpaperSlotRow(
    label: String,
    path: String,
    onAdd: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = label, modifier = Modifier.weight(1f), color = colorScheme.onBackground)
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(colorScheme.surfaceContainer)
                .clickable(onClick = onAdd),
            contentAlignment = Alignment.Center,
        ) {
            if (path.isNotEmpty() && File(path).exists()) {
                val bitmap = remember(path) { runCatching { BitmapFactory.decodeFile(path) }.getOrNull() }
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Icon(Icons.Rounded.Add, contentDescription = null, tint = colorScheme.onBackground)
                }
            } else {
                Icon(Icons.Rounded.Add, contentDescription = null, tint = colorScheme.onBackground)
            }
        }
    }
}
