package com.love.iqroot.ui.screen.colorpalette
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Water
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material.icons.rounded.Window
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.love.iqroot.R
import com.love.iqroot.ui.navigation3.Navigator
import com.love.iqroot.ui.theme.LocalEnableBlur
import com.love.iqroot.ui.util.BlurredBar
import com.love.iqroot.ui.util.rememberBlurBackdrop
import com.love.iqroot.ui.viewmodel.SettingsViewModel
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SliderPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
@Composable
fun ColorPaletteScreen(navigator: Navigator) {
    val scrollBehavior = MiuixScrollBehavior()
    val enableBlur = LocalEnableBlur.current
    val backdrop = rememberBlurBackdrop(enableBlur)
    val vm = viewModel<SettingsViewModel>()
    val s by vm.uiState.collectAsStateWithLifecycle()
    Scaffold(
        topBar = { BlurredBar(backdrop) { TopAppBar(color = if (backdrop != null) Color.Transparent else colorScheme.surface, title = stringResource(R.string.settings_theme), scrollBehavior = scrollBehavior, navigationIcon = { IconButton(onClick = { navigator.pop() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "返回") } }) } },
        popupHost = { }, contentWindowInsets = WindowInsets.systemBars.add(WindowInsets.displayCutout).only(WindowInsetsSides.Horizontal),
    ) { innerPadding ->
        LazyColumn(modifier = Modifier.scrollEndHaptic().overScrollVertical().nestedScroll(scrollBehavior.nestedScrollConnection).padding(horizontal = 12.dp), contentPadding = innerPadding, overscrollEffect = null) {
            item { Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) {
                OverlayDropdownPreference(title = stringResource(R.string.settings_theme), items = listOf("跟随系统", "浅色", "深色", "Monet 跟随", "Monet 浅色", "Monet 深色"), startAction = { Icon(Icons.Rounded.Water, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, selectedIndex = s.colorMode.coerceIn(0, 5), onSelectedIndexChange = vm::setColorMode)
                SwitchPreference(title = "启用 Monet 颜色", startAction = { Icon(Icons.Rounded.Water, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, checked = s.miuixMonet, onCheckedChange = vm::setMiuixMonet)
            } }
            item { Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) {
                SwitchPreference(title = stringResource(R.string.settings_enable_blur), summary = stringResource(R.string.settings_enable_blur_summary), startAction = { Icon(Icons.Rounded.BlurOn, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, checked = s.enableBlur, onCheckedChange = vm::setEnableBlur)
                SwitchPreference(title = stringResource(R.string.settings_floating_bottom_bar), summary = stringResource(R.string.settings_floating_bottom_bar_summary), startAction = { Icon(Icons.Rounded.Widgets, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, checked = s.enableFloatingBottomBar, onCheckedChange = vm::setEnableFloatingBottomBar)
                SwitchPreference(title = stringResource(R.string.settings_enable_glass), summary = stringResource(R.string.settings_enable_glass_summary), startAction = { Icon(Icons.Rounded.Window, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, checked = s.enableFloatingBottomBarBlur, onCheckedChange = vm::setEnableFloatingBottomBarBlur)
            } }
            item { Card(modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth()) {
                SwitchPreference(title = stringResource(R.string.settings_enable_predictive_back), summary = stringResource(R.string.settings_enable_predictive_back_summary), startAction = { Icon(Icons.Rounded.Gesture, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, checked = s.enablePredictiveBack, onCheckedChange = vm::setEnablePredictiveBack)
                SliderPreference(title = stringResource(R.string.settings_page_scale), summary = "${(s.pageScale * 100).toInt()}%", startAction = { Icon(Icons.Rounded.ScreenRotation, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, value = s.pageScale, valueRange = 0.8f..1.2f, onValueChange = vm::setPageScale)
            } }
        }
    }
}
