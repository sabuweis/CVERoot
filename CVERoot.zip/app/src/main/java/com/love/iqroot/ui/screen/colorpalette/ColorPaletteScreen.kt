package com.love.iqroot.ui.screen.colorpalette

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.love.iqroot.ui.navigation3.LocalNavigator
import com.love.iqroot.ui.navigation3.Navigator
import com.love.iqroot.ui.theme.ColorMode
import com.love.iqroot.ui.viewmodel.SettingsViewModel

@Composable
fun ColorPaletteScreen(navigator: Navigator) {
    val vm = viewModel<SettingsViewModel>()
    val s by vm.uiState.collectAsStateWithLifecycle()

    val colorMode = try {
        ColorMode.fromValue(s.colorMode)
    } catch (_: Exception) {
        ColorMode.SYSTEM
    }
    val paletteStyle = try {
        PaletteStyle.valueOf(s.colorStyle)
    } catch (_: Exception) {
        PaletteStyle.TonalSpot
    }
    val colorSpec = try {
        ColorSpec.SpecVersion.valueOf(s.colorSpec)
    } catch (_: Exception) {
        ColorSpec.SpecVersion.SPEC_2025
    }

    val state = ColorPaletteUiState(
        uiState = s,
        currentColorMode = colorMode,
        currentPaletteStyle = paletteStyle,
        currentColorSpec = colorSpec,
    )

    val actions = ColorPaletteScreenActions(
        onBack = { navigator.pop() },
        onSetThemeMode = vm::setColorMode,
        onSetMiuixMonet = vm::setMiuixMonet,
        onSetKeyColor = vm::setKeyColor,
        onSetColorStyle = vm::setColorStyle,
        onSetColorSpec = vm::setColorSpec,
        onSetColorMode = { m -> vm.setColorMode(m.value) },
        onSetEnableBlur = vm::setEnableBlur,
        onSetEnableFloatingBottomBar = vm::setEnableFloatingBottomBar,
        onSetEnableFloatingBottomBarBlur = vm::setEnableFloatingBottomBarBlur,
        onSetEnableNavigationBadge = vm::setEnableNavigationBadge,
        onSetEnablePredictiveBack = vm::setEnablePredictiveBack,
        onSetPageScale = vm::setPageScale,
    )

    ColorPaletteScreenMiuix(state, actions)
}
