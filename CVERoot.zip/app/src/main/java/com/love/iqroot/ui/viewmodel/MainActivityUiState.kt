package com.love.iqroot.ui.viewmodel
import androidx.compose.runtime.Immutable
import com.love.iqroot.ui.theme.AppSettings
@Immutable
data class MainActivityUiState(val appSettings: AppSettings, val pageScale: Float, val enableBlur: Boolean, val enableFloatingBottomBar: Boolean, val enableFloatingBottomBarBlur: Boolean)
