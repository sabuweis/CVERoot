package com.love.iqroot.ui.component.bottombar
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.love.iqroot.ui.LocalMainPagerState
import com.love.iqroot.ui.component.FloatingBottomBar
import com.love.iqroot.ui.component.FloatingBottomBarItem
import com.love.iqroot.ui.theme.LocalEnableFloatingBottomBar
import com.love.iqroot.ui.theme.LocalEnableFloatingBottomBarBlur
import com.love.iqroot.ui.util.BlurredBar
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.NavigationItem
import top.yukonga.miuix.kmp.blur.Backdrop
import top.yukonga.miuix.kmp.blur.LayerBackdrop
import top.yukonga.miuix.kmp.theme.MiuixTheme
@Composable
fun BottomBarMiuix(blurBackdrop: LayerBackdrop?, backdrop: Backdrop, modifier: Modifier) {
    val mainState = LocalMainPagerState.current
    val enableFloating = LocalEnableFloatingBottomBar.current
    val enableGlass = LocalEnableFloatingBottomBarBlur.current
    val items = BottomBarDestination.entries.map { d -> NavigationItem(label = stringResource(d.label), icon = d.icon) }
    if (!enableFloating) {
        BlurredBar(blurBackdrop) {
            NavigationBar(modifier = modifier, color = if (blurBackdrop != null) Color.Transparent else MiuixTheme.colorScheme.surface, content = {
                items.forEachIndexed { index, item -> NavigationBarItem(modifier = Modifier.weight(1f), icon = item.icon, label = item.label, selected = mainState.selectedPage == index, onClick = { mainState.animateToPage(index) }) }
            })
        }
    } else {
        FloatingBottomBar(
            modifier = modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = {}).padding(bottom = 12.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()),
            selectedIndex = { mainState.selectedPage }, onSelected = { mainState.animateToPage(it) }, backdrop = backdrop, tabsCount = items.size, isBlurEnabled = enableGlass,
        ) {
            items.forEachIndexed { index, item ->
                FloatingBottomBarItem(onClick = { mainState.animateToPage(index) }, modifier = Modifier.defaultMinSize(minWidth = 96.dp)) {
                    Icon(imageVector = item.icon, contentDescription = item.label)
                    Text(text = item.label, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 1, overflow = TextOverflow.Visible)
                }
            }
        }
    }
}
