package com.love.iqroot.ui.screen.settings
import androidx.compose.runtime.Immutable
@Immutable
data class SettingsUiState(
    val colorMode: Int = 0, val miuixMonet: Boolean = false, val keyColor: Int = 0,
    val colorStyle: String = "TonalSpot", val colorSpec: String = "SPEC_2025",
    val enablePredictiveBack: Boolean = true, val enableBlur: Boolean = true,
    val enableFloatingBottomBar: Boolean = true, val enableFloatingBottomBarBlur: Boolean = true,
    val pageScale: Float = 1.0f, val debugLog: Boolean = false,
)
@Immutable
data class SettingsScreenActions(
    val onOpenTheme: () -> Unit, val onSetDebugLog: (Boolean) -> Unit,
    val onSendLog: () -> Unit, val onOpenAbout: () -> Unit,
)
