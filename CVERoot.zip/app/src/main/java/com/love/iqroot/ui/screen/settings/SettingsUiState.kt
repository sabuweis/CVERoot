package com.love.iqroot.ui.screen.settings

import androidx.compose.runtime.Immutable

@Immutable
data class SettingsUiState(
    val uiMode: String = "miuix",
    val colorMode: Int = 0,
    val miuixMonet: Boolean = false,
    val keyColor: Int = 0,
    val colorStyle: String = "TonalSpot",
    val colorSpec: String = "SPEC_2025",
    val themeMode: Int = 0,
    val enablePredictiveBack: Boolean = true,
    val enableBlur: Boolean = true,
    val enableFloatingBottomBar: Boolean = true,
    val enableFloatingBottomBarBlur: Boolean = true,
    val enableNavigationBadge: Boolean = true,
    val pageScale: Float = 1.0f,
    val debugLog: Boolean = false,
    val wallpaperMode: Int = 0,
    val wallpaperIndependent: Boolean = false,
    val wallpaperLightPath: String = "",
    val wallpaperDarkPath: String = "",
)

@Immutable
data class SettingsScreenActions(
    val onOpenTheme: () -> Unit,
    val onSetDebugLog: (Boolean) -> Unit,
    val onSendLog: () -> Unit,
    val onOpenAbout: () -> Unit,
    val onSetUiModeIndex: (Int) -> Unit = {},
    val onSetColorMode: (Int) -> Unit = {},
    val onSetThemeMode: (Int) -> Unit = {},
    val onSetMiuixMonet: (Boolean) -> Unit = {},
    val onSetKeyColor: (Int) -> Unit = {},
    val onSetColorStyle: (String) -> Unit = {},
    val onSetColorSpec: (String) -> Unit = {},
    val onSetEnableBlur: (Boolean) -> Unit = {},
    val onSetEnableFloatingBottomBar: (Boolean) -> Unit = {},
    val onSetEnableFloatingBottomBarBlur: (Boolean) -> Unit = {},
    val onSetEnableNavigationBadge: (Boolean) -> Unit = {},
    val onSetEnablePredictiveBack: (Boolean) -> Unit = {},
    val onSetPageScale: (Float) -> Unit = {},
    val onOpenWallpaper: () -> Unit = {},
)
