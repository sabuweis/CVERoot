package com.love.iqroot.ui.screen.colorpalette

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuOpen
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.CallToAction
import androidx.compose.material.icons.rounded.Colorize
import androidx.compose.material.icons.rounded.DesignServices
import androidx.compose.material.icons.rounded.Pin
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.love.iqroot.R
import com.love.iqroot.ui.component.miuix.ScaleDialog
import com.love.iqroot.ui.theme.LocalEnableBlur
import com.love.iqroot.ui.theme.keyColorOptions
import com.love.iqroot.ui.util.BlurredBar
import com.love.iqroot.ui.util.rememberBlurBackdrop
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Slider
import top.yukonga.miuix.kmp.basic.SliderDefaults
import top.yukonga.miuix.kmp.basic.TabRow
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic

@Composable
fun ColorPaletteScreenMiuix(
    state: ColorPaletteUiState,
    actions: ColorPaletteScreenActions,
) {
    val scrollBehavior = MiuixScrollBehavior()
    val enableBlur = LocalEnableBlur.current
    val backdrop = rememberBlurBackdrop(enableBlur)
    val barColor = if (backdrop != null) Color.Transparent else colorScheme.surface
    val s = state.uiState

    Scaffold(
        topBar = {
            BlurredBar(backdrop) {
                TopAppBar(
                    color = barColor,
                    title = stringResource(R.string.settings_theme),
                    navigationIcon = {
                        top.yukonga.miuix.kmp.basic.IconButton(onClick = actions.onBack) {
                            Icon(
                                androidx.compose.material.icons.Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = null,
                                tint = colorScheme.onBackground,
                            )
                        }
                    },
                    scrollBehavior = scrollBehavior,
                )
            }
        },
        popupHost = { },
        contentWindowInsets = WindowInsets.systemBars
            .add(WindowInsets.displayCutout)
            .only(WindowInsetsSides.Horizontal),
    ) { innerPadding ->
        val showScaleDialog = rememberSaveable { mutableStateOf(false) }

        Box(modifier = if (backdrop != null) Modifier.layerBackdrop(backdrop) else Modifier) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxHeight()
                    .scrollEndHaptic()
                    .overScrollVertical()
                    .nestedScroll(scrollBehavior.nestedScrollConnection)
                    .padding(horizontal = 12.dp),
                contentPadding = innerPadding,
                overscrollEffect = null,
            ) {
                item {
                    Spacer(Modifier.height(16.dp))

                    // 主题模式（跟随系统 / 浅色 / 深色）
                    TabRow(
                        tabs = listOf(
                            stringResource(R.string.settings_theme_mode_system),
                            stringResource(R.string.settings_theme_mode_light),
                            stringResource(R.string.settings_theme_mode_dark),
                        ),
                        selectedTabIndex = (if (s.colorMode >= 3) s.colorMode - 3 else s.colorMode).coerceIn(0, 2),
                        onTabSelected = { actions.onSetThemeMode(it) },
                    )

                    // Monet 开关
                    Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) {
                        SwitchPreference(
                            title = stringResource(R.string.settings_monet),
                            startAction = {
                                Icon(Icons.Rounded.Wallpaper, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                            },
                            checked = s.miuixMonet,
                            onCheckedChange = actions.onSetMiuixMonet,
                        )
                        AnimatedVisibility(visible = s.miuixMonet) {
                            Column {
                                val colorItems = listOf(
                                            stringResource(R.string.settings_key_color_default),
                                            stringResource(R.string.color_red),
                                            stringResource(R.string.color_pink),
                                            stringResource(R.string.color_purple),
                                            stringResource(R.string.color_deep_purple),
                                            stringResource(R.string.color_indigo),
                                            stringResource(R.string.color_blue),
                                            stringResource(R.string.color_cyan),
                                            stringResource(R.string.color_teal),
                                            stringResource(R.string.color_green),
                                            stringResource(R.string.color_yellow),
                                            stringResource(R.string.color_amber),
                                            stringResource(R.string.color_orange),
                                            stringResource(R.string.color_brown),
                                            stringResource(R.string.color_blue_grey),
                                            stringResource(R.string.color_sakura),
                                        )
                                val colorValues = listOf(0) + keyColorOptions
                                OverlayDropdownPreference(
                                    title = stringResource(R.string.settings_key_color),
                                    items = colorItems,
                                    startAction = {
                                        Icon(Icons.Rounded.Colorize, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                                    },
                                    selectedIndex = colorValues.indexOf(s.keyColor).takeIf { it >= 0 } ?: 0,
                                    onSelectedIndexChange = { idx -> actions.onSetKeyColor(colorValues[idx]) },
                                )
                                AnimatedVisibility(visible = s.keyColor != 0) {
                                    Column {
                                        val styles = PaletteStyle.entries
                                        OverlayDropdownPreference(
                                            title = stringResource(R.string.settings_color_style),
                                            items = styles.map { it.name },
                                            startAction = {
                                                Icon(Icons.Rounded.Style, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                                            },
                                            selectedIndex = styles.indexOfFirst { it.name == s.colorStyle }.coerceAtLeast(0),
                                            onSelectedIndexChange = { idx -> actions.onSetColorStyle(styles[idx].name) },
                                        )
                                        val specs = ColorSpec.SpecVersion.entries
                                        OverlayDropdownPreference(
                                            title = stringResource(R.string.settings_color_spec),
                                            items = specs.map { it.name },
                                            startAction = {
                                                Icon(Icons.Rounded.DesignServices, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                                            },
                                            selectedIndex = specs.indexOfFirst { it.name == s.colorSpec }.coerceAtLeast(0),
                                            onSelectedIndexChange = { idx -> actions.onSetColorSpec(specs[idx].name) },
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 模糊 + 悬浮底栏 + 液态玻璃（联动）
                    Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            SwitchPreference(
                                title = stringResource(R.string.settings_enable_blur),
                                summary = stringResource(R.string.settings_enable_blur_summary),
                                startAction = {
                                    Icon(Icons.Rounded.BlurOn, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                                },
                                checked = s.enableBlur,
                                onCheckedChange = actions.onSetEnableBlur,
                            )
                        }
                        SwitchPreference(
                            title = stringResource(R.string.settings_floating_bottom_bar),
                            summary = stringResource(R.string.settings_floating_bottom_bar_summary),
                            startAction = {
                                Icon(Icons.Rounded.CallToAction, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                            },
                            checked = s.enableFloatingBottomBar,
                            onCheckedChange = actions.onSetEnableFloatingBottomBar,
                        )
                        AnimatedVisibility(
                            visible = s.enableFloatingBottomBar && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU,
                        ) {
                            SwitchPreference(
                                title = stringResource(R.string.settings_enable_glass),
                                summary = stringResource(R.string.settings_enable_glass_summary),
                                startAction = {
                                    Icon(Icons.Rounded.WaterDrop, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                                },
                                checked = s.enableFloatingBottomBarBlur,
                                onCheckedChange = actions.onSetEnableFloatingBottomBarBlur,
                            )
                        }
                        SwitchPreference(
                            title = stringResource(R.string.settings_navigation_badge),
                            summary = stringResource(R.string.settings_navigation_badge_summary),
                            startAction = {
                                Icon(Icons.Rounded.Pin, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                            },
                            checked = s.enableNavigationBadge,
                            onCheckedChange = actions.onSetEnableNavigationBadge,
                        )
                    }

                    // 预测返回 + 界面缩放
                    Card(modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                            SwitchPreference(
                                title = stringResource(R.string.settings_enable_predictive_back),
                                summary = stringResource(R.string.settings_enable_predictive_back_summary),
                                startAction = {
                                    Icon(Icons.AutoMirrored.Rounded.MenuOpen, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                                },
                                checked = s.enablePredictiveBack,
                                onCheckedChange = actions.onSetEnablePredictiveBack,
                            )
                        }

                        // 滑块拖动不实时应用，松手才生效；点击数字弹输入框
                        var sliderValue by remember(s.pageScale) { mutableFloatStateOf(s.pageScale) }
                        ArrowPreference(
                            title = stringResource(R.string.settings_page_scale),
                            summary = stringResource(R.string.settings_page_scale_summary),
                            startAction = {
                                Icon(Icons.Rounded.AspectRatio, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground)
                            },
                            endActions = {
                                Text(
                                    text = "${(sliderValue * 100).toInt()}%",
                                    color = colorScheme.onSurfaceVariantActions,
                                )
                            },
                            onClick = { showScaleDialog.value = !showScaleDialog.value },
                            holdDownState = showScaleDialog.value,
                            bottomAction = {
                                Slider(
                                    value = sliderValue,
                                    onValueChange = { sliderValue = it },
                                    onValueChangeFinished = { actions.onSetPageScale(sliderValue) },
                                    valueRange = 0.8f..1.1f,
                                    showKeyPoints = true,
                                    keyPoints = listOf(0.8f, 0.9f, 1f, 1.1f),
                                    magnetThreshold = 0.01f,
                                    hapticEffect = SliderDefaults.SliderHapticEffect.Step,
                                )
                            },
                        )
                        ScaleDialog(
                            show = showScaleDialog.value,
                            onDismissRequest = { showScaleDialog.value = false },
                            volumeState = { s.pageScale },
                            onVolumeChange = actions.onSetPageScale,
                        )
                    }

                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}
