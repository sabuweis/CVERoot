package com.love.iqroot.ui.screen.wallpaper

import androidx.compose.runtime.Immutable

@Immutable
data class WallpaperUiState(
    val mode: Int = 0,
    val independent: Boolean = false,
    val lightPath: String = "",
    val darkPath: String = "",
)

@Immutable
data class WallpaperScreenActions(
    val onBack: () -> Unit,
    val onSetMode: (Int) -> Unit,
    val onSetIndependent: (Boolean) -> Unit,
    val onSetLightPath: (String) -> Unit,
    val onSetDarkPath: (String) -> Unit,
)
