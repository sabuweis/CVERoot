package com.love.iqroot.ui.navigation3
import android.os.Parcelable
import androidx.navigation3.runtime.NavKey
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable
sealed interface Route : NavKey, Parcelable {
    @Parcelize @Serializable data object Main : Route
    @Parcelize @Serializable data object Home : Route
    @Parcelize @Serializable data object Settings : Route
    @Parcelize @Serializable data object About : Route
    @Parcelize @Serializable data object ColorPalette : Route
    @Parcelize @Serializable data object KSuRoot : Route
    @Parcelize @Serializable data object GhostLock : Route
    @Parcelize @Serializable data object Wallpaper : Route
}
