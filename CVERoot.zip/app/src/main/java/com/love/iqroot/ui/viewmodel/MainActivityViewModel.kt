package com.love.iqroot.ui.viewmodel
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.love.iqroot.CVERootApp
import com.love.iqroot.data.repository.SettingsRepository
import com.love.iqroot.data.repository.SettingsRepositoryImpl
import com.love.iqroot.ui.theme.ThemeController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
class MainActivityViewModel(h: SavedStateHandle) : ViewModel() {
    private val prefs = CVERootApp.instance.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val settingRepo: SettingsRepository = SettingsRepositoryImpl()
    private val mainPageState = MainPageState(h)
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> if (key == null || key in observedKeys) _uiState.value = readUiState() }
    private val _uiState = MutableStateFlow(readUiState())
    val uiState: StateFlow<MainActivityUiState> = _uiState.asStateFlow()
    val selectedMainPage: StateFlow<Int> = mainPageState.selectedPage
    init { prefs.registerOnSharedPreferenceChangeListener(listener) }
    override fun onCleared() { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    fun setSelectedMainPage(page: Int) { mainPageState.updateSelectedPage(page) }
    private fun readUiState() = MainActivityUiState(ThemeController.getAppSettings(), settingRepo.pageScale, settingRepo.enableBlur, settingRepo.enableFloatingBottomBar, settingRepo.enableFloatingBottomBarBlur)
    private companion object { val observedKeys = setOf("color_mode","key_color","color_style","color_spec","miuix_monet","page_scale","enable_blur","enable_floating_bottom_bar","enable_floating_bottom_bar_blur","enable_predictive_back") }
}
private const val SELECTED_MAIN_PAGE_KEY = "selected_main_page"
private class MainPageState(private val h: SavedStateHandle) { val selectedPage: StateFlow<Int> = h.getStateFlow(SELECTED_MAIN_PAGE_KEY, 0); fun updateSelectedPage(page: Int) { h[SELECTED_MAIN_PAGE_KEY] = page.coerceIn(0, 1) } }
object MainPagerConfig { const val PAGE_COUNT = 2; const val LAST_PAGE_INDEX = PAGE_COUNT - 1; fun coercePage(page: Int): Int = page.coerceIn(0, LAST_PAGE_INDEX) }
