package com.love.iqroot.ui.screen.settings
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.ContactPage
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Send
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.love.iqroot.R
import com.love.iqroot.ui.theme.LocalEnableBlur
import com.love.iqroot.ui.util.BlurredBar
import com.love.iqroot.ui.util.rememberBlurBackdrop
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
@Composable
fun SettingPagerMiuix(uiState: SettingsUiState, actions: SettingsScreenActions, bottomInnerPadding: Dp) {
    val scrollBehavior = MiuixScrollBehavior()
    val enableBlur = LocalEnableBlur.current
    val backdrop = rememberBlurBackdrop(enableBlur)
    val barColor = if (backdrop != null) Color.Transparent else colorScheme.surface
    Scaffold(
        topBar = { BlurredBar(backdrop) { TopAppBar(color = barColor, title = stringResource(R.string.settings), scrollBehavior = scrollBehavior) } },
        popupHost = { },
        contentWindowInsets = WindowInsets.systemBars.add(WindowInsets.displayCutout).only(WindowInsetsSides.Horizontal),
    ) { innerPadding ->
        Box(modifier = if (backdrop != null) Modifier.layerBackdrop(backdrop) else Modifier) {
            LazyColumn(
                modifier = Modifier.fillMaxHeight().scrollEndHaptic().overScrollVertical().nestedScroll(scrollBehavior.nestedScrollConnection).padding(horizontal = 12.dp),
                contentPadding = innerPadding, overscrollEffect = null,
            ) {
                item { Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) { ArrowPreference(title = stringResource(R.string.settings_theme), summary = stringResource(R.string.settings_theme_summary), startAction = { Icon(Icons.Rounded.Palette, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, onClick = actions.onOpenTheme) } }
                item { Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) { SwitchPreference(title = stringResource(R.string.settings_debug_log), summary = stringResource(R.string.settings_debug_log_summary), startAction = { Icon(Icons.Rounded.BugReport, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, checked = uiState.debugLog, onCheckedChange = actions.onSetDebugLog) } }
                item { Card(modifier = Modifier.padding(top = 12.dp).fillMaxWidth()) { ArrowPreference(title = stringResource(R.string.send_log), startAction = { Icon(Icons.Rounded.Send, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, onClick = actions.onSendLog) } }
                item { Card(modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth()) { ArrowPreference(title = stringResource(R.string.about), startAction = { Icon(Icons.Rounded.ContactPage, null, Modifier.padding(end = 6.dp), tint = colorScheme.onBackground) }, onClick = actions.onOpenAbout) }; Spacer(Modifier.height(bottomInnerPadding)) }
            }
        }
    }
}
