package com.love.iqroot.ui.screen.about

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalUriHandler
import androidx.lifecycle.compose.dropUnlessResumed
import com.love.iqroot.BuildConfig
import com.love.iqroot.ui.navigation3.LocalNavigator

@Composable
fun AboutScreen() {
    val navigator = LocalNavigator.current
    val uriHandler = LocalUriHandler.current
    val htmlString =
        "<a href=\"https://github.com/sabuweis/CVERoot\">在 GitHub 查看源码</a>"
    val state = AboutUiState(
        title = "关于",
        appName = "CVERoot",
        versionName = BuildConfig.VERSION_NAME,
        links = extractLinks(htmlString),
    )
    val actions = AboutScreenActions(
        onBack = dropUnlessResumed { navigator.pop() },
        onOpenLink = uriHandler::openUri,
    )
    AboutScreenMiuix(state, actions)
}
