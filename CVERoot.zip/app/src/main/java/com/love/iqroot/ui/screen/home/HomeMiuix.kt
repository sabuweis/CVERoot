package com.love.iqroot.ui.screen.home
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import top.yukonga.miuix.kmp.basic.Button
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.theme.MiuixTheme.colorScheme
@Composable
fun HomePagerMiuix(onKSuRootClick: () -> Unit, onGhostLockClick: () -> Unit, bottomInnerPadding: Dp) {
    Scaffold(contentWindowInsets = WindowInsets.systemBars.add(WindowInsets.displayCutout).only(WindowInsetsSides.Horizontal)) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxHeight().fillMaxWidth().padding(innerPadding).padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Text("选择提权模式", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = colorScheme.onBackground)
            Spacer(Modifier.height(48.dp))
            Button(onClick = onKSuRootClick, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColorsPrimary(), cornerRadius = 32.dp) { Text("KSuRoot", fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(20.dp))
            Button(onClick = onGhostLockClick, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColorsPrimary(), cornerRadius = 32.dp) { Text("GhostLock", fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(bottomInnerPadding))
        }
    }
}
