package com.love.iqroot.ui.screen.home

import android.content.Context
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Build
import android.system.Os
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.getValue
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.love.iqroot.BuildConfig
import com.love.iqroot.R
import com.love.iqroot.ui.component.liquid.lens
import com.love.iqroot.ui.component.liquid.vibrancy
import com.love.iqroot.ui.theme.isInDarkTheme
import java.io.File
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.blur.LayerBackdrop
import top.yukonga.miuix.kmp.blur.blur
import top.yukonga.miuix.kmp.blur.drawBackdrop
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.blur.rememberLayerBackdrop
import top.yukonga.miuix.kmp.utils.PressFeedbackType

@Composable
fun HomePagerMiuix(
    onKSuRootClick: () -> Unit,
    onGhostLockClick: () -> Unit,
    bottomInnerPadding: Dp,
) {
    val backdrop = rememberLayerBackdrop {
        drawRect(Color.White)
        drawContent()
    }

    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var wallpaperMode by remember { mutableIntStateOf(prefs.getInt("wallpaper_mode", 0)) }
    var wallpaperIndependent by remember { mutableStateOf(prefs.getBoolean("wallpaper_independent", false)) }
    var wallpaperLightPath by remember { mutableStateOf(prefs.getString("wallpaper_light_path", "") ?: "") }
    var wallpaperDarkPath by remember { mutableStateOf(prefs.getString("wallpaper_dark_path", "") ?: "") }

    DisposableEffect(prefs) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            when (key) {
                "wallpaper_mode" -> wallpaperMode = prefs.getInt("wallpaper_mode", 0)
                "wallpaper_independent" -> wallpaperIndependent = prefs.getBoolean("wallpaper_independent", false)
                "wallpaper_light_path" -> wallpaperLightPath = prefs.getString("wallpaper_light_path", "") ?: ""
                "wallpaper_dark_path" -> wallpaperDarkPath = prefs.getString("wallpaper_dark_path", "") ?: ""
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    val isDark = isInDarkTheme()
    val wallpaperPath = remember(wallpaperMode, wallpaperIndependent, wallpaperLightPath, wallpaperDarkPath, isDark) {
        if (wallpaperMode != 1) null
        else {
            val path = if (wallpaperIndependent && isDark) wallpaperDarkPath else wallpaperLightPath
            path.takeIf { it.isNotEmpty() && File(it).exists() }
        }
    }
    val customBitmap = remember(wallpaperPath) {
        wallpaperPath?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.systemBars
            .add(WindowInsets.displayCutout)
            .only(WindowInsetsSides.Horizontal),
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .layerBackdrop(backdrop)
            ) {
                if (customBitmap != null) {
                    Image(
                        bitmap = customBitmap.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Image(
                        painter = painterResource(if (isInDarkTheme()) R.drawable.home_bg_dark else R.drawable.home_bg),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
                contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
            ) {
                item { HomeStatusCard() }
                item { LiquidGlassButton(backdrop, "KSuRoot", onKSuRootClick) }
                item { LiquidGlassButton(backdrop, "GhostLock", onGhostLockClick) }
                item { DeviceInfoCard(backdrop) }
                item { Spacer(Modifier.height(bottomInnerPadding)) }
            }
        }
    }
}

@Composable
private fun HomeStatusCard() {
    val cardColor = Color(0xFFDFFAE4)
    val iconTint = Color(0xFF36D167)
    val textColor = Color(0xFF1A3825)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.defaultColors(color = cardColor),
        pressFeedbackType = PressFeedbackType.Tilt,
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp),
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 12.dp, bottom = 12.dp),
                ) {
                    Icon(
                        modifier = Modifier.size(64.dp),
                        imageVector = Icons.Rounded.CheckCircleOutline,
                        tint = iconTint,
                        contentDescription = null,
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 16.dp, top = 16.dp),
                ) {
                    Column {
                        Text(
                            text = "CVERoot",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = textColor,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "版本 1.5",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = textColor,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassButton(
    backdrop: LayerBackdrop,
    text: String,
    onClick: () -> Unit,
) {
    val pillShape = RoundedCornerShape(32.dp)
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 1.2f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "btnScale",
    )
    val tilt by animateFloatAsState(
        targetValue = if (pressed) 3f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "btnTilt",
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                rotationX = tilt
            }
            .clip(pillShape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
            ) { onClick() }
            .drawBackdrop(
                backdrop = backdrop,
                shape = { pillShape },
                effects = {
                    vibrancy()
                    if (!pressed) {
                        blur(4.dp.toPx(), 4.dp.toPx())
                    }
                    val k = if (pressed) 1.08f else 1f
                    lens(
                        refractionHeight = 20.dp.toPx() * k,
                        refractionAmount = 18.dp.toPx() * k,
                        depthEffect = true,
                        chromaticAberration = if (pressed) 0.7f else 0.55f,
                    )
                },
                onDrawSurface = {
                    drawRect(Color.White.copy(alpha = if (pressed) 0.10f else 0.18f))
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun DeviceInfoCard(backdrop: LayerBackdrop) {
    val cardShape = RoundedCornerShape(24.dp)
    val info = rememberDeviceInfo()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.defaultColors(color = Color.Transparent),
        pressFeedbackType = PressFeedbackType.Tilt,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(cardShape)
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { cardShape },
                    effects = {
                        vibrancy()
                        blur(8.dp.toPx(), 8.dp.toPx())
                        lens(
                            refractionHeight = 24.dp.toPx(),
                            refractionAmount = 22.dp.toPx(),
                            depthEffect = true,
                            chromaticAberration = 0.4f,
                        )
                    },
                    onDrawSurface = {
                        drawRect(Color.White.copy(alpha = 0.14f))
                    },
                )
                .padding(horizontal = 20.dp, vertical = 20.dp),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                info.forEachIndexed { idx, (label, value) ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = label,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = value,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Normal,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                        if (idx != info.lastIndex) {
                            Spacer(Modifier.height(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun rememberDeviceInfo(): List<Pair<String, String>> {
    return remember {
        listOf(
            "管理器版本" to "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
            "内核版本" to Os.uname().release,
            "设备型号" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "系统指纹" to Build.FINGERPRINT,
            "Seccomp 状态" to readSeccompStatus(),
        )
    }
}

private fun readSelinuxStatus(): String {
    return try {
        val ctx = java.io.File("/proc/self/attr/current").readText().trim()
        // 例如 "u:r:untrusted_app:s0:c163,c257,c512,c768"
        val domain = ctx.split(":").getOrNull(2) ?: ""
        if (domain.contains("permissive", ignoreCase = true)) "宽容模式"
        else if (domain.isNotEmpty()) "强制执行"
        else "未知"
    } catch (_: Exception) {
        "未知"
    }
}

private fun readSeccompStatus(): String {
    return try {
        val lines = java.io.File("/proc/self/status").readLines()
        val line = lines.firstOrNull { it.startsWith("Seccomp:") } ?: return "未知"
        when (line.substringAfter(":").trim()) {
            "0" -> "未启用"
            "1" -> "严格模式"
            "2" -> "过滤模式"
            else -> "未知"
        }
    } catch (_: Exception) {
        "未知"
    }
}
