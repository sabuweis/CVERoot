package com.love.iqroot.ui.screen.home

import android.os.Build
import android.system.Os
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.love.iqroot.BuildConfig
import com.love.iqroot.R
import com.love.iqroot.ui.component.liquid.lens
import com.love.iqroot.ui.component.liquid.vibrancy
import com.love.iqroot.ui.theme.isInDarkTheme
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.blur.LayerBackdrop
import top.yukonga.miuix.kmp.blur.blur
import top.yukonga.miuix.kmp.blur.drawBackdrop
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.blur.rememberLayerBackdrop
import top.yukonga.miuix.kmp.utils.PressFeedbackType

@Composable
fun HomePagerMiuix(
    onKSuRootClick: () -> Unit,
    onGhostLockClick: () -> Unit,
    bottomInnerPadding: Dp,
) {
    val backdrop = rememberLayerBackdrop {
        drawRect(Color.White)
        drawContent()
    }

    Scaffold(
        contentWindowInsets = WindowInsets.systemBars
            .add(WindowInsets.displayCutout)
            .only(WindowInsetsSides.Horizontal),
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .layerBackdrop(backdrop)
            ) {
                Image(
                    painter = painterResource(if (isInDarkTheme()) R.drawable.home_bg_dark else R.drawable.home_bg),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 8.dp),
            ) {
                item { HomeStatusCard() }
                item { LiquidGlassButton(backdrop, "KSuRoot", onKSuRootClick) }
                item { LiquidGlassButton(backdrop, "GhostLock", onGhostLockClick) }
                item { DeviceInfoCard(backdrop) }
                item { Spacer(Modifier.height(bottomInnerPadding)) }
            }
        }
    }
}

@Composable
private fun HomeStatusCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.defaultColors(
            color = Color(0xFFDFFAE4),
        ),
        pressFeedbackType = PressFeedbackType.Tilt,
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp),
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 12.dp, bottom = 12.dp),
                ) {
                    Icon(
                        modifier = Modifier.size(64.dp),
                        imageVector = Icons.Rounded.CheckCircleOutline,
                        tint = Color(0xFF36D167),
                        contentDescription = null,
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 16.dp, top = 16.dp),
                ) {
                    Column {
                        Text(
                            text = "CVERoot",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1A3825),
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "版本 1.3",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1A3825),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassButton(
    backdrop: LayerBackdrop,
    text: String,
    onClick: () -> Unit,
) {
    val pillShape = RoundedCornerShape(32.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(pillShape)
            .clickable(onClick = onClick)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { pillShape },
                effects = {
                    vibrancy()
                    blur(4.dp.toPx(), 4.dp.toPx())
                    lens(
                        refractionHeight = 20.dp.toPx(),
                        refractionAmount = 18.dp.toPx(),
                        depthEffect = true,
                        chromaticAberration = 0.4f,
                    )
                },
                onDrawSurface = {
                    drawRect(Color.White.copy(alpha = 0.18f))
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun DeviceInfoCard(backdrop: LayerBackdrop) {
    val cardShape = RoundedCornerShape(24.dp)
    val info = rememberDeviceInfo()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(cardShape)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { cardShape },
                effects = {
                    vibrancy()
                    blur(8.dp.toPx(), 8.dp.toPx())
                    lens(
                        refractionHeight = 24.dp.toPx(),
                        refractionAmount = 22.dp.toPx(),
                        depthEffect = true,
                        chromaticAberration = 0.5f,
                    )
                },
                onDrawSurface = {
                    drawRect(Color.White.copy(alpha = 0.14f))
                },
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            info.chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    pair.forEach { (label, value) ->
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = label,
                                color = Color.White.copy(alpha = 0.75f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = value,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                        }
                    }
                    if (pair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun rememberDeviceInfo(): List<Pair<String, String>> {
    return remember {
        listOf(
            "管理器版本" to "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
            "内核版本" to Os.uname().release,
            "设备型号" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "系统指纹" to Build.FINGERPRINT,
            "SELinux 状态" to readSelinuxStatus(),
            "Seccomp 状态" to readSeccompStatus(),
        )
    }
}

private fun readSelinuxStatus(): String {
    return try {
        val content = java.io.File("/sys/fs/selinux/enforce").readText().trim()
        if (content == "1") "强制执行" else "宽容模式"
    } catch (_: Exception) {
        "未知"
    }
}

private fun readSeccompStatus(): String {
    return try {
        val ret = Os.prctl(21, 0L, 0L, 0L, 0L)
        when (ret) {
            0 -> "未启用"
            1 -> "严格模式"
            2 -> "过滤模式"
            else -> "未知"
        }
    } catch (_: Exception) {
        "未知"
    }
}
